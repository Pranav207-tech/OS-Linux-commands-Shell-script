#!/usr/bin/python3

print("give me a bottle of rum!")
