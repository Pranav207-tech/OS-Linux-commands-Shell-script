#include <iostream>

using namespace std;

main()
{
	cout << "give me a bottle of rum!" << endl;
	return 0;
}
