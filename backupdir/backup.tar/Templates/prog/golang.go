package main
import "fmt"
func main() {
    fmt.Println("give me a bottle of rum!")
}

