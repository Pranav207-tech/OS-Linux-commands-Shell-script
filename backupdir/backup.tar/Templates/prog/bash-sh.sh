#!/bin/bash

echo "give me a bottle of rum!"
