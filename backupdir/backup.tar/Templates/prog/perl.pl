#!/usr/bin/perl

print("give me a bottle of rum!");
