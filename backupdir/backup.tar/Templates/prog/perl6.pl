#!/usr/bin/perl6

say "give me a bottle of rum!";
