#!/bin/bash
echo "About to try to access a file that doesn't exist"
cat bad-filename.txt
